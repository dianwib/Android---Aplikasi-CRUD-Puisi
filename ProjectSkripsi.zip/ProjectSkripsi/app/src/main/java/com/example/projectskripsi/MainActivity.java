package com.example.projectskripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
LinearLayout linearLayout;
Button btn_puisi,btn_kumpus,btn_materi,btn_pengaturan,btn_draft,btn_musikalisasi,btn_musik;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_draft=findViewById(R.id.btn_draf);
        btn_kumpus=findViewById(R.id.btn_kumpus);
        btn_materi=findViewById(R.id.btn_materi);
        btn_musik=findViewById(R.id.btn_musik);
        btn_musikalisasi=findViewById(R.id.btn_musikalisasi);
        btn_pengaturan=findViewById(R.id.btn_pengaturan);

        btn_materi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a =new Intent(MainActivity.this,MateriActivity.class);
                startActivity(a);
            }
        });
        btn_draft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a =new Intent(MainActivity.this,DraftActivity.class);
                startActivity(a);
            }
        });

    }
}
