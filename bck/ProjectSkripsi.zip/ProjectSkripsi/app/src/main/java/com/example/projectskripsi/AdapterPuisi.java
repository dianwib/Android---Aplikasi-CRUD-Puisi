package com.example.projectskripsi;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//Class Adapter ini Digunakan Untuk Mengatur Bagaimana Data akan Ditampilkan
public class AdapterPuisi extends RecyclerView.Adapter<AdapterPuisi.ViewHolder>{


    //Deklarasi Variable
    private ArrayList<Puisi> listPuisi;
    private Context context;

    //Membuat Konstruktor, untuk menerima input dari Database
    public AdapterPuisi(ArrayList<Puisi> listPuisi, Context context) {
        this.listPuisi = listPuisi;
        this.context = context;
    }

    //ViewHolder Digunakan Untuk Menyimpan Referensi Dari View-View
    class ViewHolder extends RecyclerView.ViewHolder{

        private TextView Judul, Nama, Tanggal;
        private LinearLayout ListItem;

        ViewHolder(View itemView) {
            super(itemView);
            //Menginisialisasi View-View yang terpasang pada layout RecyclerView kita
            Judul = itemView.findViewById(R.id.judul);
            Nama = itemView.findViewById(R.id.nama);
            Tanggal = itemView.findViewById(R.id.tanggal);
            ListItem = itemView.findViewById(R.id.list_item);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //Membuat View untuk Menyiapkan dan Memasang Layout yang Akan digunakan pada RecyclerView
        View V = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_puisi, parent, false);
        return new ViewHolder(V);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        //Mengambil Nilai/Value yenag terdapat pada RecyclerView berdasarkan Posisi Tertentu
        final String Judul = listPuisi.get(position).getJudul();
        final String Nama = listPuisi.get(position).getNama();
        final String Tanggal = listPuisi.get(position).getTanggal();

        //Memasukan Nilai/Value kedalam View (TextView: NIM, Nama, Jurusan)
        holder.Judul.setText(Judul);
        holder.Nama.setText("Oleh : "+Nama);
        holder.Tanggal.setText(Tanggal);

        holder.ListItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {

                Bundle bundle = new Bundle();
                bundle.putString("datajudul", listPuisi.get(position).getJudul());
                bundle.putString("datanama", listPuisi.get(position).getNama());
                bundle.putString("dataisi", listPuisi.get(position).getIsi());
                bundle.putString("getPrimaryKey", listPuisi.get(position).getKey());
                Intent intent = new Intent(v.getContext(), LihatPuisiDetil.class);
                intent.putExtras(bundle);
                context.startActivity(intent);

                /*
                  Kodingan untuk membuat fungsi Edit dan Delete,
                  yang akan dibahas pada Tutorial Berikutnya.
                 */
return true;
            }
        });

    }




    @Override
    public int getItemCount() {
        //Menghitung Ukuran/Jumlah Data Yang Akan Ditampilkan Pada RecyclerView
        return listPuisi.size();
    }

}