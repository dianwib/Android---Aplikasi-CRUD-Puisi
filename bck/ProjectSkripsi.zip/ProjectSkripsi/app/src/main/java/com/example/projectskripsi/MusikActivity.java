package com.example.projectskripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MusikActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_musik);
    }
}
